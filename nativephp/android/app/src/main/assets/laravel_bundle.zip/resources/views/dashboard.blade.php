<x-layouts.app :title="__('Dashboard')">
    <div class="">
        <livewire:sketch-board />
    </div>
</x-layouts.app>
